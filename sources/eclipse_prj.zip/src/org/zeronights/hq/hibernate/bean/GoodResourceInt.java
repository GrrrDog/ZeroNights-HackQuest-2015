package org.zeronights.hq.hibernate.bean;

import org.restlet.representation.Representation;
import org.restlet.resource.Get;
import org.restlet.resource.Post;
import org.restlet.resource.Put;

public interface GoodResourceInt {

	@Get
	public Representation listGoods();

	@Post
	public Representation addGood(Representation entity);
	
	@Put
	public Representation deleteGood(Representation entity);
}
