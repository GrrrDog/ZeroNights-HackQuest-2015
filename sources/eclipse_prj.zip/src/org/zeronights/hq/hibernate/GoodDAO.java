package org.zeronights.hq.hibernate;

import java.util.ArrayList;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.zeronights.hq.hibernate.bean.Good;

public class GoodDAO {

	public Integer addGood(Good good) {
		Configuration configuration = new Configuration().configure();
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();

		Good existGood = (Good) session.get(good.getClass(), good.getId());
		if (existGood != null) {
			System.out.println(existGood.getName());
			return 0;
		}

		Transaction tx = null;
		try {
			tx = session.beginTransaction();
			session.save(good);
			tx.commit();
		} catch (HibernateException e) {

			if (tx != null)
				tx.rollback();
			throw e;
		} finally {
			session.close();
			sessionFactory.close();
		}
		return 1;

	}

	public Integer deleteGood(Integer id) {

		// 1. configuring hibernate
		Configuration configuration = new Configuration().configure();

		// 2. create sessionfactory
		SessionFactory sessionFactory = configuration.buildSessionFactory();

		// 3. Get Session object
		Session session = sessionFactory.openSession();

		Good existGood = (Good) session.get(Good.class, id);
		if (existGood == null) {

			return 0;
		}

		System.out.println(existGood.getName());

		Transaction tx = null;
		try {
			tx = session.beginTransaction();
			session.delete(existGood);
			tx.commit();
		} catch (HibernateException e) {

			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
			sessionFactory.close();
		}

		return 1;

	}

	@SuppressWarnings("unchecked")
	public ArrayList<Good> searchGoods(String pattern) {
		ArrayList<Good> goods = null;
		// 1. configuring hibernate
		Configuration configuration = new Configuration().configure();

		// 2. create sessionfactory
		SessionFactory sessionFactory = configuration.buildSessionFactory();

		// 3. Get Session object
		Session session = sessionFactory.openSession();
		String stmtHQL;

		// Transaction tx = null;
		try {
			// tx = session.beginTransaction();
			// System.out.println("pattern " + pattern);
			if (pattern == null || pattern.equals("")) {

				stmtHQL = "FROM Good";
			} else {
				// System.out.println("pattern " + pattern);
				stmtHQL = "FROM Good WHERE name='" + pattern + "'";
			}

			goods = (ArrayList<Good>) session.createQuery(stmtHQL).list();

			// tx.commit();
		} catch (HibernateException e) {
			// if (tx != null)
			// tx.rollback();
			e.printStackTrace();
		} finally {
			// System.out.println("closed");
			session.close();
			sessionFactory.close();
		}

		return goods;
	}

}
