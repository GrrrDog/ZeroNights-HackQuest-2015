package org.zeronights.hq.restlet;

import java.io.IOException;
import java.util.ArrayList;

import org.restlet.data.MediaType;
import org.restlet.data.Status;
import org.restlet.representation.ObjectRepresentation;
import org.restlet.representation.Representation;
import org.restlet.representation.StringRepresentation;
import org.restlet.resource.ServerResource;
import org.zeronights.hq.hibernate.GoodDAO;
import org.zeronights.hq.hibernate.bean.Good;
import org.zeronights.hq.hibernate.bean.GoodResourceInt;

public class GoodResource extends ServerResource implements GoodResourceInt {
	GoodDAO goodDAO = new GoodDAO();

	@Override
	public Representation listGoods() {
		
		ArrayList<Good> goods;

		goods = goodDAO.searchGoods(null);
		ObjectRepresentation<ArrayList<Good>> repObject = new ObjectRepresentation<ArrayList<Good>>(goods,MediaType.APPLICATION_JAVA_OBJECT_XML);
		return repObject;
	}

	@Override
	public Representation addGood(Representation entity) {
		Representation reply = null;
		Good good = null;

		// System.out.println("repObject");
		ObjectRepresentation<Good> repObject = null;

		try {

			try {
				repObject = new ObjectRepresentation<Good>(entity);
				// System.out.println("repObject1");

			} catch (IOException e) {
				setStatus(Status.SERVER_ERROR_INTERNAL);
				return new StringRepresentation("IOException", MediaType.TEXT_PLAIN);
			}

		} catch (ClassNotFoundException e) {
			setStatus(Status.SERVER_ERROR_INTERNAL);
			return new StringRepresentation("ClassNotFoundException", MediaType.TEXT_PLAIN);
		}

		try {
			// System.out.println("good=repObject.getObject();");
			good = repObject.getObject();
		} catch (IOException e) {
			setStatus(Status.SERVER_ERROR_INTERNAL);
			return new StringRepresentation("IOException", MediaType.TEXT_PLAIN);
		}
		// System.out.println(good.getName());

		if (goodDAO.addGood(good) == 0) {
			setStatus(Status.SUCCESS_OK);
			reply = new StringRepresentation(
					"That's OK, but the product already exists somewhere in the Universe",
					MediaType.TEXT_PLAIN);
		} else {

			setStatus(Status.SUCCESS_CREATED);
			reply = new StringRepresentation("The product has been added", MediaType.TEXT_PLAIN);
		}

		return reply;
	}

	@Override
	public Representation deleteGood(Representation entity) {
		
		Representation reply = null;
		Integer id=null;

		// System.out.println("repObject");
		ObjectRepresentation<Integer> repObject = null;

		try {

			try {
				repObject = new ObjectRepresentation<Integer>(entity);
				// System.out.println("repObject1");

			} catch (IOException e) {
				setStatus(Status.SERVER_ERROR_INTERNAL);
				return new StringRepresentation("IOException", MediaType.TEXT_PLAIN);
			}

		} catch (ClassNotFoundException e) {
			setStatus(Status.SERVER_ERROR_INTERNAL);
			return new StringRepresentation("ClassNotFoundException", MediaType.TEXT_PLAIN);
		}

		try {
			// System.out.println("good=repObject.getObject();");
			id = repObject.getObject();
		} catch (IOException e) {
			setStatus(Status.SERVER_ERROR_INTERNAL);
			return new StringRepresentation("IOException", MediaType.TEXT_PLAIN);
		}
		// System.out.println(good.getName());

		if (goodDAO.deleteGood(id) == 0) {
			setStatus(Status.SUCCESS_OK);
			reply = new StringRepresentation(
					"You can't delete the nothing but that's OK",
					MediaType.TEXT_PLAIN);
		} else {

			setStatus(Status.SUCCESS_CREATED);
			reply = new StringRepresentation("The product has been deleted", MediaType.TEXT_PLAIN);
		}

		return reply;
		
	}

}
