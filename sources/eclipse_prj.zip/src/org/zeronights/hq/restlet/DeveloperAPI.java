package org.zeronights.hq.restlet;

import java.sql.SQLException;
import java.util.HashMap;

import javax.naming.NamingException;

import org.restlet.Application;
import org.restlet.Restlet;
import org.restlet.data.ChallengeScheme;
import org.restlet.routing.Router;
import org.restlet.security.ChallengeAuthenticator;
import org.restlet.security.MapVerifier;
import org.zeronights.hq.java.DAO;

public class DeveloperAPI extends Application {

	/**
	 * Creates a root Restlet that will receive all incoming calls.
	 */
	@Override
	public synchronized Restlet createInboundRoot() {
		DAO dao;
		HashMap<String, String> developers =null;
		try {
			dao=new DAO();
			developers=dao.getDevUsers();
			
		} catch (SQLException | NamingException e) {
			e.printStackTrace();
		}
		MapVerifier verifier = new MapVerifier();
		
		for(String devName: developers.keySet()){
            //System.out.println(devName  +" :: "+ developers.get(devName));
            verifier.getLocalSecrets().put(devName, developers.get(devName).toCharArray());
        }
		
        // Create a Guard
        ChallengeAuthenticator guard = new ChallengeAuthenticator(getContext(),
                ChallengeScheme.HTTP_BASIC, "Developer API");
        guard.setVerifier(verifier);
               
		Router router = new Router(getContext());
		router.attach("/hello", HelloWorldResource.class);
		router.attach("/prods", GoodResource.class);
        guard.setNext(router);
        return guard;

	}
}
