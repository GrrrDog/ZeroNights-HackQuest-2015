package org.zeronights.hq.restlet.test;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;

import org.restlet.data.ChallengeResponse;
import org.restlet.data.ChallengeScheme;
import org.restlet.data.MediaType;
import org.restlet.engine.io.BioUtils;
import org.restlet.representation.ObjectRepresentation;
import org.restlet.representation.OutputRepresentation;
import org.restlet.representation.Representation;
import org.restlet.representation.Variant;
import org.restlet.resource.ClientResource;
import org.zeronights.hq.hibernate.bean.Good;
import org.zeronights.hq.hibernate.bean.GoodResourceInt;

public class Client {

	public static void main(String[] args) throws IOException {

		ClientResource cr = new ClientResource("http://192.168.182.151:8088/ZN_HQ/API/prods") {
			  @Override
			public Representation toRepresentation(Object source, Variant target) {
			    Representation result = null;
			    if (source != null) {
			      org.restlet.service.ConverterService cs = getConverterService();
			      result = cs.toRepresentation(source, target, this);
			      if (result != null) {
			        try {
			          final ByteArrayOutputStream os = new ByteArrayOutputStream();
			          BioUtils.copy(result.getStream(), os);
			          OutputRepresentation rep = new OutputRepresentation(
			            result.getMediaType()) {
			              @Override
			              public void write(OutputStream outputStream) throws IOException {
			                outputStream.write(os.toByteArray());
			              }
			            };
			          rep.setSize(os.size());
			          result = rep;
			        } catch (IOException e) {
			          e.printStackTrace();
			        }
			      }
			    }
			  return result;
			 }
			};

		ChallengeScheme scheme = ChallengeScheme.HTTP_BASIC;
		ChallengeResponse authentication = new ChallengeResponse(scheme, "developer_Vasia", "fpBA7BPlS8wJ");
		cr.setChallengeResponse(authentication);

		GoodResourceInt resource = cr.wrap(GoodResourceInt.class);
		

		try {
			ArrayList<Good> goods;
			ObjectRepresentation<ArrayList<Good>> repObjectList = new ObjectRepresentation<ArrayList<Good>>(
					resource.listGoods());
			goods = repObjectList.getObject();

			System.out.println("  id	|	name	|  price	");
			for (Good good : goods) {
				System.out.printf("%4d	|%10s	|%4d	%n", good.getId(), good.getName(),
						good.getPrice());
			}
		} catch (ClassNotFoundException | IllegalArgumentException e) {
			e.printStackTrace();
		}

		System.out.println("");
		System.out.println("Let's add something?");
		
		Representation reply = null;
		Good good = new Good(11, "ZeroNigths", 80);
		ObjectRepresentation<Good> repObjectAdd = new ObjectRepresentation<Good>(good,MediaType.APPLICATION_JAVA_OBJECT_XML);
		reply=resource.addGood(repObjectAdd);
		System.out.println(reply.getText());

		System.out.println("");
		System.out.println("Let's delete something?");
		Integer idGood = new Integer(11);
		ObjectRepresentation<Integer> repObjectDelete = new ObjectRepresentation<Integer>(idGood,MediaType.APPLICATION_JAVA_OBJECT_XML);
		reply = resource.deleteGood(repObjectDelete);

		System.out.println(reply.getText());

	}

}
