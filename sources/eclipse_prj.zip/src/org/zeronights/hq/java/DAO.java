package org.zeronights.hq.java;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class DAO {
	private Connection conn;

	public DAO(Connection conn) {
		this.conn = conn;
	}

	public DAO() throws SQLException, NamingException {
		try {
			InitialContext init = new InitialContext();
			Context env = (Context) init.lookup("java:comp/env");
			DataSource ds = (DataSource) env.lookup("jdbc/webappdb");
			this.conn = ds.getConnection();

		} catch (NamingException e) {
			throw new NamingException();

		}
	}

	public Boolean login(String username, String password) throws SQLException {
		Boolean authed = null;
		PreparedStatement stmt = conn
				.prepareStatement("select count(*) from users where username =? and password=? ");
		stmt.setString(1, username);
		stmt.setString(2, password);

		ResultSet rs = stmt.executeQuery();

		if (rs.next()) {
			if (rs.getInt("count(*)") == 0) {
				authed = false;
			} else {
				authed = true;
			}

		}
		rs.close();
		stmt.close();

		// System.out.println(authed);
		return authed;

	}

	public void closeConn() throws SQLException {
		conn.close();
	}

	public void deleteUser(String username) throws SQLException {

		PreparedStatement stmt = conn.prepareStatement("DELETE FROM users WHERE username = ?");
		stmt.setString(1, username);
		stmt.executeUpdate();
		stmt.close();
		// conn.close();
	}

	public void addUser(String username, String password) throws SQLException {

		PreparedStatement stmt = conn
				.prepareStatement("insert into users (username, password) values(?,?)");
		stmt.setString(1, username);
		stmt.setString(2, password);
		stmt.executeUpdate();
		stmt.close();
		// conn.close();
	}

	public ArrayList<String> getUsers() throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("select username from users");
		ResultSet rs = stmt.executeQuery();

		ArrayList<String> results = new ArrayList<String>();

		while (rs.next()) {
			results.add(rs.getString("username"));

		}
		rs.close();
		stmt.close();
		// conn.close();
		return results;

	}

	public HashMap<String, String> getDevUsers() throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("select username, password from developers");
		ResultSet rs = stmt.executeQuery();

		HashMap<String, String> results = new HashMap<String, String>();

		while (rs.next()) {
			results.put(rs.getString("username"), rs.getString("password"));
		}
		rs.close();
		stmt.close();
		conn.close();
		return results;

	}

}
